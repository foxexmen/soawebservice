package clientesoapesfot;


public class ClienteSOAPESFOT {

    public static void main(String[] args) 
    {
        
       System.out.println("RESULTADO DE 8 AL CUADRADO: "+cuadrado(8));
       
       System.out.println("RESULTADO DE RECTANGULO 8 * 5: "+rectangulo(8,5));
       
       System.out.println("RESULTADO DE TRIANGULO (5 * 4) /2: "+triangulo(5,4));
           
    }

    private static double cuadrado(double lado1) {
        uddi.Figuras_Service service = new uddi.Figuras_Service();
        uddi.Figuras port = service.getFigurasPort();
        return port.cuadrado(lado1);
    }

    private static double rectangulo(double lado1, double lado2) {
        uddi.Figuras_Service service = new uddi.Figuras_Service();
        uddi.Figuras port = service.getFigurasPort();
        return port.rectangulo(lado1, lado2);
    }

    private static double triangulo(double lado1, double lado2) {
        uddi.Figuras_Service service = new uddi.Figuras_Service();
        uddi.Figuras port = service.getFigurasPort();
        return port.triangulo(lado1, lado2);
    }
    
    
    
    
}
